<?xml version="1.0" encoding="UTF-8"?>
<tileset name="walls" tilewidth="100" tileheight="100" tilecount="35" columns="5">
 <image source="walls.png" width="500" height="700"/>
</tileset>
